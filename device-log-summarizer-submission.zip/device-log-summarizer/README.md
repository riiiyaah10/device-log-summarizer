# Device Log Summarizer CLI

A Python command-line tool for cleaning sensor readings, summarizing device telemetry from CSV, exporting JSON, and generating a temperature comparison chart.

## Requirements

- Python 3.10+
- Dependencies listed in `requirements.txt`

## Setup

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

## Run Section 1 function

```bash
python -c "from src.sanitization import clean_sensor_readings; print(clean_sensor_readings(['12', None, -2, 700, 'bad']))"
```

Expected result:

```text
[12.0, 500.0]
```

## Run Section 2: CSV aggregation

```bash
python -m src.main --input data/device_telemetry.csv --output outputs/summary.json
```

The program prints a terminal summary and writes the JSON output. Rows with a blank device ID or invalid/non-finite temperature are skipped. Devices with an average temperature greater than 80.0 are excluded.

## Run Section 3: chart generation

```bash
python -m src.chart --input outputs/summary.json --output outputs/temperature_chart.png
```

The chart is saved as a PNG file.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Project structure

```text
device-log-summarizer/
├── data/
│   └── device_telemetry.csv
├── outputs/
│   ├── summary.json
│   └── temperature_chart.png
├── src/
│   ├── aggregation.py
│   ├── chart.py
│   ├── main.py
│   └── sanitization.py
├── tests/
│   ├── test_aggregation.py
│   └── test_sanitization.py
├── PROMPT_LOG.md
├── README.md
└── requirements.txt
```

## Input data note

The assessment PDF describes `device_telemetry.csv` but does not include the actual CSV attachment. The included CSV is illustrative sample data for demonstrating and testing the solution. Replace it with the assessment-provided file if one is supplied separately.
