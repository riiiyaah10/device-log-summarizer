"""Section 3: generate a bar chart from the Section 2 JSON output."""

import json
from pathlib import Path
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def create_temperature_chart(json_path: str | Path, output_path: str | Path) -> None:
    source = Path(json_path)
    if not source.is_file():
        raise FileNotFoundError(f"JSON file not found: {source}")

    with source.open("r", encoding="utf-8") as handle:
        records = json.load(handle)

    if not isinstance(records, list):
        raise ValueError("Expected the JSON file to contain a list of device summaries.")

    device_ids = [item["device_id"] for item in records]
    averages = [float(item["average_temperature"]) for item in records]

    fig, ax = plt.subplots(figsize=(9, 5))
    if device_ids:
        bars = ax.bar(device_ids, averages)
        ax.bar_label(bars, fmt="%.1f", padding=3)
        ax.set_ylim(0, max(averages) * 1.18 if max(averages) > 0 else 1)
    else:
        ax.text(0.5, 0.5, "No devices to display", ha="center", va="center",
                transform=ax.transAxes)

    ax.set_title("Average Temperature by Device")
    ax.set_xlabel("Device ID")
    ax.set_ylabel("Average temperature")
    ax.grid(axis="y", linestyle="--", alpha=0.35)
    ax.set_axisbelow(True)
    plt.setp(ax.get_xticklabels(), rotation=25, ha="right")
    fig.tight_layout()

    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destination, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Chart average device temperatures.")
    parser.add_argument("--input", default="outputs/summary.json")
    parser.add_argument("--output", default="outputs/temperature_chart.png")
    args = parser.parse_args()
    create_temperature_chart(args.input, args.output)
    print(f"Chart saved to: {args.output}")


if __name__ == "__main__":
    main()
