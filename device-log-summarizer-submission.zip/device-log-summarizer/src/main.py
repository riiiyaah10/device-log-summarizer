"""Command-line entry point for the Device Log Summarizer."""

import argparse
from pathlib import Path

from src.aggregation import aggregate_telemetry, export_json, print_summary


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize device telemetry CSV logs.")
    parser.add_argument("--input", default="data/device_telemetry.csv",
                        help="Path to the input CSV file.")
    parser.add_argument("--output", default="outputs/summary.json",
                        help="Path for the aggregated JSON output.")
    args = parser.parse_args()

    try:
        results = aggregate_telemetry(args.input)
        export_json(results, args.output)
        print_summary(results)
        print(f"\nJSON summary saved to: {args.output}")
    except (FileNotFoundError, ValueError, OSError) as exc:
        parser.exit(1, f"Error: {exc}\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
