"""Section 1: clean and normalize mixed sensor readings."""

from typing import Iterable


def clean_sensor_readings(values: Iterable[object]) -> list[float]:
    """Convert valid non-negative values to floats and cap values at 500.0.

    Values that are None, cannot be converted, are NaN/infinite, or are
    negative are discarded. An empty or entirely invalid input returns [].
    """
    cleaned: list[float] = []

    for value in values:
        if value is None:
            continue
        try:
            number = float(value)
        except (TypeError, ValueError, OverflowError):
            continue

        # NaN and infinity are not useful sensor readings.
        if number != number or number in (float("inf"), float("-inf")):
            continue
        if number < 0:
            continue

        cleaned.append(min(number, 500.0))

    return cleaned
