"""Section 2: aggregate device telemetry CSV data and export JSON."""

import csv
import json
from collections import defaultdict
from pathlib import Path
from typing import Any


def aggregate_telemetry(csv_path: str | Path) -> list[dict[str, Any]]:
    """Aggregate valid rows by device_id, excluding mean temperatures > 80.

    Rows missing a device ID or containing an invalid/non-finite temperature
    are skipped. Status comparison is case-insensitive after trimming.
    """
    path = Path(csv_path)
    if not path.is_file():
        raise FileNotFoundError(f"CSV file not found: {path}")

    grouped: dict[str, dict[str, Any]] = defaultdict(
        lambda: {"temperatures": [], "error_count": 0, "record_count": 0}
    )

    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        required = {"device_id", "status", "temperature"}
        headers = set(reader.fieldnames or [])
        missing = required - headers
        if missing:
            raise ValueError("CSV is missing required column(s): " + ", ".join(sorted(missing)))

        for line_number, row in enumerate(reader, start=2):
            device_id = (row.get("device_id") or "").strip()
            if not device_id:
                continue

            raw_temperature = (row.get("temperature") or "").strip()
            try:
                temperature = float(raw_temperature)
            except (TypeError, ValueError, OverflowError):
                continue

            if temperature != temperature or temperature in (float("inf"), float("-inf")):
                continue

            status = (row.get("status") or "").strip().upper()
            bucket = grouped[device_id]
            bucket["temperatures"].append(temperature)
            bucket["record_count"] += 1
            if status == "ERROR":
                bucket["error_count"] += 1

    results = []
    for device_id, values in sorted(grouped.items()):
        temperatures = values["temperatures"]
        if not temperatures:
            continue
        average = sum(temperatures) / len(temperatures)
        if average > 80.0:
            continue
        results.append({
            "device_id": device_id,
            "total_records": values["record_count"],
            "average_temperature": round(average, 2),
            "error_count": values["error_count"],
        })

    return results


def export_json(results: list[dict[str, Any]], output_path: str | Path) -> None:
    """Write aggregation results as readable JSON, creating parent folders."""
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=4)
        handle.write("\n")


def print_summary(results: list[dict[str, Any]]) -> None:
    """Print a compact terminal summary without external dependencies."""
    headers = ("DEVICE", "RECORDS", "AVG TEMP", "ERRORS")
    rows = [
        (r["device_id"], str(r["total_records"]),
         f'{r["average_temperature"]:.2f}', str(r["error_count"]))
        for r in results
    ]
    widths = [
        max(len(headers[i]), *(len(row[i]) for row in rows)) if rows else len(headers[i])
        for i in range(len(headers))
    ]
    fmt = "  ".join("{:<" + str(width) + "}" for width in widths)
    print(fmt.format(*headers))
    print(fmt.format(*("-" * width for width in widths)))
    for row in rows:
        print(fmt.format(*row))
    if not rows:
        print("No devices matched the aggregation and temperature criteria.")
