import unittest

from src.sanitization import clean_sensor_readings


class SanitizationTests(unittest.TestCase):
    def test_converts_filters_and_clips(self):
        self.assertEqual(
            clean_sensor_readings(["12", 23.5, None, -4, "bad", 700]),
            [12.0, 23.5, 500.0],
        )

    def test_empty_and_all_invalid(self):
        self.assertEqual(clean_sensor_readings([]), [])
        self.assertEqual(clean_sensor_readings([None, "x", -1]), [])

    def test_discards_non_finite_values(self):
        self.assertEqual(clean_sensor_readings(["nan", "inf", 0]), [0.0])


if __name__ == "__main__":
    unittest.main()
