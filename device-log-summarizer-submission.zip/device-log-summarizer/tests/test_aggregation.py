import csv
import json
import tempfile
import unittest
from pathlib import Path

from src.aggregation import aggregate_telemetry, export_json


class AggregationTests(unittest.TestCase):
    def write_csv(self, path, rows):
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["device_id", "status", "temperature"])
            writer.writeheader()
            writer.writerows(rows)

    def test_groups_counts_filters_and_exports(self):
        with tempfile.TemporaryDirectory() as folder:
            csv_path = Path(folder) / "input.csv"
            json_path = Path(folder) / "nested" / "summary.json"
            self.write_csv(csv_path, [
                {"device_id": "DEV_A", "status": "ACTIVE", "temperature": "40"},
                {"device_id": "DEV_A", "status": "ERROR", "temperature": "60"},
                {"device_id": "DEV_B", "status": "WARNING", "temperature": "90"},
                {"device_id": "DEV_C", "status": "ERROR", "temperature": "bad"},
            ])
            result = aggregate_telemetry(csv_path)
            self.assertEqual(result, [{
                "device_id": "DEV_A", "total_records": 2,
                "average_temperature": 50.0, "error_count": 1
            }])
            export_json(result, json_path)
            self.assertEqual(json.loads(json_path.read_text()), result)

    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            aggregate_telemetry("does-not-exist.csv")


if __name__ == "__main__":
    unittest.main()
