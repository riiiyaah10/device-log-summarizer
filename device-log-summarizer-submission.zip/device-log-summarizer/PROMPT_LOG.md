# AI Prompt Log

## Scope

This log records the AI assistance used while preparing this project. The assessment asks for an initial prompt, an observed issue in the first charting attempt, and a follow-up prompt for Section 3.

## Section 2 — Core data processing

**Prompt used:**

> Write a readable Python CLI program that reads a CSV containing device_id, status, and temperature; groups valid rows by device_id; calculates record count, average temperature, and ERROR count; excludes devices whose average temperature is above 80.0; exports JSON; and prints a terminal summary. Include handling for missing files, missing columns, and malformed temperature values.

**Review decisions:**

- Checked that required CSV headers are present.
- Skipped rows with missing device IDs or invalid/non-finite temperatures.
- Counted ERROR statuses case-insensitively.
- Created output directories when needed and used a non-zero exit on input errors.

## Section 3 — AI prompting and charting

**Initial prompt used:**

> Write a Python script that loads the JSON summary produced by my device telemetry aggregation script and creates a matplotlib bar chart comparing average temperature per device. Include a title and axis labels and save the chart as a PNG.

**Issue identified during review:**

The first charting approach did not rotate long device labels or reserve enough space below the x-axis. With multiple device IDs, labels could overlap or be clipped.

**Follow-up prompt used:**

> Update the chart so device labels are rotated and right-aligned, use tight_layout and bbox_inches='tight' when saving, add readable value labels above the bars, and handle an empty JSON list without crashing. Keep the input and output paths configurable.

**Changes made:**

- Rotated and right-aligned x-axis labels.
- Added `fig.tight_layout()` and saved with `bbox_inches="tight"`.
- Added value labels, axis labels, a chart title, and a grid.
- Added an empty-data message.

## Section 1 — Coding logic and sanitization

The assessment explicitly specifies that this section is intended to test independent coding without AI. The included `src/sanitization.py` and its tests are provided as a reference implementation in this prepared project. Before submitting, independently rewrite and verify this section yourself if you need to comply with that condition. Do not represent AI-generated or AI-assisted work as independently authored.
